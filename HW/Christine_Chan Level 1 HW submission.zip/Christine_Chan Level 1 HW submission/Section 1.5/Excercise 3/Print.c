//
//  Print.c
//  L1S1.5E3
//
//  Created by Christine Chan on 10/29/19.
//  Copyright © 2019 Christine Chan. All rights reserved.
//

#include <stdio.h>

int second(int x)
{
    return x*2;
}
