//
//  main.c
//  L1S1.5E3
//
//  Created by Christine Chan on 10/29/19.
//  Copyright © 2019 Christine Chan. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int i = 3;
    printf("print: %d\n", second(i));
    return 0;
}
