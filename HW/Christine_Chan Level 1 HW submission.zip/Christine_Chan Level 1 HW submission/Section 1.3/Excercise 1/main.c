//
//  main.c
//  Level 1 S1.3 E1
//
//  Created by Christine on 2019/8/26.
//  Copyright © 2019 Christine. All rights reserved.
//

#include <stdio.h>

int main() {
    // insert code here...
    printf("My first C-program\n");
    printf("is a fact!\n");
    printf("Good, isn’t it?\n");
    return 0;
}
