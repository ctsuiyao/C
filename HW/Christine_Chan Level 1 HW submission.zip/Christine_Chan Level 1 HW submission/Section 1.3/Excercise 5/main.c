//
//  main.c
//  L1S1.3E5
//
//  Created by Christine on 2019/8/26.
//  Copyright © 2019 Christine. All rights reserved.
//

#include <stdio.h>

int main() {
    int i = 0;
    printf("%d\n",i); // print 0
    printf("%d\n",--i); // print -1, (minus then print i)
    printf("%d\n",i);
    printf("%d\n",i--); // print -1, then minus 1
    printf("%d\n",i); // print -2
    return 0;
}
